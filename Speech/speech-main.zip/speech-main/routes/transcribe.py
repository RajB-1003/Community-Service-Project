# backend/routes/transcribe.py
from fastapi import APIRouter, UploadFile, File, Form, HTTPException
from fastapi.responses import JSONResponse
from faster_whisper import WhisperModel
import tempfile
import os
import torch
from pydub import AudioSegment

router = APIRouter()

# GPU if available
device = "cuda" if torch.cuda.is_available() else "cpu"

# Whisper Turbo model for Indian languages
model = WhisperModel(
    "deepdml/faster-whisper-large-v3-turbo-ct2",
    device=device,
    compute_type="int8"  # float16 if good NVIDIA GPU
)

ALLOWED_LANGS = {"en", "ta", "ml", "hi"}

def run_whisper(path, language):
    segments, info = model.transcribe(
        path,
        language=language,
        beam_size=5,
        word_timestamps=False,
        vad_filter=True,
        vad_parameters=dict(min_silence_duration_ms=500),
        condition_on_previous_text=False
    )
    full_text = " ".join(seg.text for seg in segments)
    return full_text.strip()

def convert_to_wav(input_path):
    """Convert any audio format to WAV for Whisper"""
    with tempfile.NamedTemporaryFile(delete=False, suffix=".wav") as tmp_wav:
        AudioSegment.from_file(input_path).export(tmp_wav.name, format="wav")
        return tmp_wav.name

@router.post("/transcribe")
async def transcribe(file: UploadFile = File(...), language: str = Form(...)):
    if language not in ALLOWED_LANGS:
        return JSONResponse({"text": "Language not supported"}, status_code=400)

    # Save uploaded file temporarily
    with tempfile.NamedTemporaryFile(delete=False, suffix=Path(file.filename).suffix or ".webm") as tmp:
        tmp.write(await file.read())
        tmp_path = tmp.name

    try:
        # Convert to WAV for Whisper if needed
        wav_path = convert_to_wav(tmp_path)
        text = run_whisper(wav_path, language)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Transcription failed: {e}")
    finally:
        # Clean up temporary files
        if os.path.exists(tmp_path):
            os.remove(tmp_path)
        if 'wav_path' in locals() and os.path.exists(wav_path):
            os.remove(wav_path)

    return {"text": text}